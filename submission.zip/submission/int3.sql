.mode columns
.headers on
.nullvalue NULL
select count(*) as numberOfRecords from Record;